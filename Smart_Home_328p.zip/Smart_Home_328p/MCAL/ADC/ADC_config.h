/*********************************************************/
/* Component : ADC                                      */
/* File      : ADC_config.h                             */
/* Author    : Ahmed Hegazy                                     */
/* Date      : 28 . 8 . 2023                             */
/* Version   : V1.0                                      */
/*********************************************************/

#ifndef MCAL_ADC_ADC_CONFIG_H_
#define MCAL_ADC_ADC_CONFIG_H_



#endif /* MCAL_ADC_ADC_CONFIG_H_ */
