/*********************************************************/
/* Component : DIO                                       */
/* File      : DIO_config.h                              */
/* Author    : Ahmed Hegazy                              */
/* Date      : 25 . 4 . 2024                             */
/* Version   : V1.0                                      */
/*********************************************************/

/*preprocessor header file guard*/
#ifndef MCAL_DIO_DIO_CONFIG_H_
#define MCAL_DIO_DIO_CONFIG_H_



#endif /* MCAL_DIO_DIO_CONFIG_H_ */
