/*********************************************************/
/* Component : WDT                                      */
/* File      : WDT_config.h                             */
/* Author    : Ahmed Hegazy                                         */
/* Date      : 16 . 9 . 2023                             */
/* Version   : V1.0                                      */
/*********************************************************/

#ifndef MCAL_WDT_WDT_CONFIG_H_
#define MCAL_WDT_WDT_CONFIG_H_



#endif /* MCAL_WDT_WDT_CONFIG_H_ */
