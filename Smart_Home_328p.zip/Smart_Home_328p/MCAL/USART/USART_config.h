/*********************************************************/
/* Component : USART                                      */
/* File      : USART_config.h                             */
/* Author    : Ahmed Hegazy                                     */
/* Date      : 21 . 9 . 2023                             */
/* Version   : V1.0                                      */


#ifndef MCAL_USART_USART_CONFIG_H_
#define MCAL_USART_USART_CONFIG_H_



#endif /* MCAL_USART_USART_CONFIG_H_ */
