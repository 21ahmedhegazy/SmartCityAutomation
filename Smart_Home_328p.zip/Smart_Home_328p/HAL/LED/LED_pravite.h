/*********************************************************/
/* Component : LED                                     */
/* File      : LED_private.h                             */
/* Author    : Ahmed Hegazy                                       */
/* Date      : 28 . 8 . 2023                             */
/* Version   : V1.0                                      */
/*********************************************************/
#ifndef HAL_LED_LED_PRAVITE_H_
#define HAL_LED_LED_PRAVITE_H_



#endif /* HAL_LED_LED_PRAVITE_H_ */
