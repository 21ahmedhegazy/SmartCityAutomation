/*********************************************************/
/* Component : LED                                     */
/* File      : LED_config.h                             */
/* Author    : Ahmed Hegazy                                       */
/* Date      : 28 . 8 . 2023                             */
/* Version   : V1.0                                      */
/*********************************************************/


#ifndef HAL_LED_LED_CONFIG_H_
#define HAL_LED_LED_CONFIG_H_



#endif /* HAL_LED_LED_CONFIG_H_ */
