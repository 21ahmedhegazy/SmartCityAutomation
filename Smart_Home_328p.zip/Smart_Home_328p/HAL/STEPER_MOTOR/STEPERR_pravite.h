/*********************************************************/
/* Component : STEPPER_MOTOR                                     */
/* File      : STM_private.h                             */
/* Author    : Ahmed Hegazy                                      */
/* Date      : 28 . 8 . 2023                             */
/* Version   : V1.0                                      */
/*********************************************************/

#ifndef HAL_STEPER_MOTOR_STEPERR_PRAVITE_H_
#define HAL_STEPER_MOTOR_STEPERR_PRAVITE_H_



#endif /* HAL_STEPER_MOTOR_STEPERR_PRAVITE_H_ */
