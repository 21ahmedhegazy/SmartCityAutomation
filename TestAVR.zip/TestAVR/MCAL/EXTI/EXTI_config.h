/*********************************************************/
/* Component : EXTI                                      */
/* File      : EXTI_config.h                             */
/* Author    : Hegazy                                     */
/* Date      : 17 . 7 . 2023                             */
/* Version   : V1.0                                      */
/*********************************************************/

#ifndef MCAL_EXTI_EXTI_CONFIG_H_
#define MCAL_EXTI_EXTI_CONFIG_H_



#endif /* MCAL_EXTI_EXTI_CONFIG_H_ */
