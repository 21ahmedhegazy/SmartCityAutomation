/************************************/
/* Component : DIO                  */
/* File      : DIO_Config.h         */
/* Author    : Ahmed Hegazy          */
/* Date 	 : 15/7/2023            */
/* Version 	 : V1.0                 */
/************************************/

#ifndef MCAL_DIO_DIO_CONFIG_H_
#define MCAL_DIO_DIO_CONFIG_H_



#endif /* MCAL_DIO_DIO_CONFIG_H_ */
