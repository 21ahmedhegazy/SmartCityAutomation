/*********************************************************/
/* Component : ADC                                      */
/* File      : ADC_interface.h                             */
/* Author    : Ezzat                                     */
/* Date      : 28 . 8 . 2023                             */
/* Version   : V1.0                                      */
/*********************************************************/

#ifndef MCAL_ADC_ADC_INTERFACE_H_
#define MCAL_ADC_ADC_INTERFACE_H_



void adcinit();
int adcread(char);


#endif /* MCAL_ADC_ADC_INTERFACE_H_ */
