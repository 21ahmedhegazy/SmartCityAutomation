/*
 * USART_CONFIG.h
 *
 *  Created on: Aug 10, 2022
 *      Author: Hegazy
 */

#ifndef _UART_CONFIG_H
#define _UART_CONFIG_H



#endif /* UART_CONFIG_H_ */
