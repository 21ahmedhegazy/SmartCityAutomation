#ifndef TIMER1_CONFIG_H
#define TIMER1_CONFIG_H


#define TIMER1_MODE

#endif
