/*
 * MQ.h
 *
 *  Created on: Jan 6, 2025
 *      Author: pc
 */

#ifndef HAL_MH_MQ_SENSOR_MQ_H_
#define HAL_MH_MQ_SENSOR_MQ_H_
#include "../../LIB/BIT_MATH.h"
#include "../../LIB/STD_TYPES.h"


#define RL_VALUE (10)        // Load resistance in kilo-ohms
#define GAS_THRESHOLD 50     // Threshold resistance value to detect gas (arbitrary example)

float ResistanceCalculation(int raw_adc);
float ReadSensor(void);
#endif /* HAL_MH_MQ_SENSOR_MQ_H_ */
