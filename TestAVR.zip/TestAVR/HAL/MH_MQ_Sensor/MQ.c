/*
 * MQ.c
 *
 *  Created on: Jan 6, 2025
 *      Author: pc
 */
#include "../../LIB/BIT_MATH.h"
#include "../../LIB/STD_TYPES.h"
#include "../../MCAL/ADC/ADC_interface.h"
#include <util/delay.h>
#include "MQ.h"

float ResistanceCalculation(int raw_adc)
{
    // Calculate sensor resistance based on ADC value
    if (raw_adc == 0)
    {
        return RL_VALUE * 1023; // Avoid division by zero
    }
    return (float)(RL_VALUE * (1023 - raw_adc) / raw_adc);
}

float ReadSensor(void)
{
    int i;
    float rs = 0;

    // Take multiple readings and average the sensor resistance
    for (i = 0; i < 5; i++)
    {
        rs += ResistanceCalculation(adcread(0)); // Replace with your ADC channel
        _delay_ms(50);
    }

    return rs / 5; // Return average resistance
}
