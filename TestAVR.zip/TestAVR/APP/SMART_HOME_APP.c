/************************************/
/* File      : SMART_HOME_APP.c     */
/* Author    : Ahmed Hegazy        */
/* Date 	 : 8/10/2023            */
/* Version 	 : V1.0                 */
/************************************/
/************<include drivers from LIB layer>************/
 #include "../LIB/STD_TYPES.h"
 #include "../LIB/BIT_MATH.h"
/**********************************************/

/************<include drivers from MCAL layer>************/
 #include "../MCAL/DIO/DIO_Interface.h"
 #include "../MCAL/USART/UART_Interface.h"
/**********************************************/

/************<include drivers from HAL layer>************/

 #include "../HAL/SERVO/SERVO_Interface.h"
 #include "../HAL/LED/LED_Interface.h"
 #include "../HAL/BUZZER/BUZZER_Interface.h"
 #include "../HAL/MH_MQ_Sensor/MQ.h"
/**********************************************/


/************<include delay library>************/
 #include <util/delay.h>
/**********************************************/

/*********<include SMART HOME library>*********/
#include "SMART_HOME_Interface.h"
/**********************************************/


// Send initialization commands to the Wi-Fi module
void Wifi_voidInit()
{
	UART_voidSendStringSync("AT+CWJAP=\"ZOZ\",\"100100100\"\r\n");
	  _delay_ms(1000);                             // Wait for command to process

	  UART_voidSendStringSync("AT+CIPMUX=1\r\n");  // Enable multiple connections
	  _delay_ms(1000);                             // Wait for command to process
	  UART_voidSendStringSync("AT+CIPSERVER=1,80\r\n");  // Start server on port 80
	  _delay_ms(1000);
}




// Function to initialize the raindrop sensor and return rain status
u8 Raindrop_voidInit(void)
{
    // Read the raindrop sensor pin value and determine if it's raining
    u8 isRaining = (DIO_u8GetPinValue(PORTA, PIN4) == 0); // Active LOW signal indicates rain
    return isRaining; // Return the status as the function output
}

// Function to control the window based on rain detection
u8 checkRain(u8 isRaining)
{
    if (isRaining)
    {
        SERVO_voidRotate2(90);  // Open the window if it's raining
        return 1;               // Return 1 to indicate the window was opened
    }
    else
    {
        SERVO_voidRotate2(0);  // Close the window if it's not raining
        return 0;               // Return 0 to indicate the window was closed
    }
}
//void ReadSmokeSensor(void)
//{
//    static u8 gasDetected = 0;  // Variable to track if gas was detected previously
//    float sensor_resistance = 0;
//
//    // Read the sensor resistance (average over 5 readings)
//    sensor_resistance = ReadSensor();
//
//    // If resistance is below the threshold, gas is detected
//    if (sensor_resistance < GAS_THRESHOLD)
//    {
//        if (!gasDetected) {
//            // Gas detected, turn on LED and set the gasDetected flag
//            LED_voidLedOff(PORTA, PIN7, VCC);
//            LED_voidLedOff(PORTA, PIN1, VCC);
//            gasDetected = 1;
//
//            // Wait for 500 ms after detecting gas
//            _delay_ms(500);
//        }
//    }
//    else
//    {
//        if (gasDetected) {
//            // If gas is removed, turn off LED and reset the flag
//            LED_voidLedOn(PORTA, PIN7, VCC);
//            LED_voidLedOn(PORTA, PIN1, VCC);
//            gasDetected = 0;
//
//            // Wait for 500 ms to ensure the sensor value is stable after removing the gas
//            _delay_ms(500);
//        }
//    }
//}

void SmokeSensor (void)
{
	if (DIO_u8GetPinValue(PORTA,PIN0)== LOW)
	{
		DIO_voidSetPinValue(PORTA,PIN7,HIGH);
		DIO_voidSetPinValue(PORTA,PIN1,HIGH);
		_delay_ms(2000);
		DIO_voidSetPinValue(PORTA,PIN7,LOW);
		DIO_voidSetPinValue(PORTA,PIN1,LOW);

	}
	else
	{
		DIO_voidSetPinValue(PORTA,PIN7,LOW);
		DIO_voidSetPinValue(PORTA,PIN1,LOW);
	}
}

